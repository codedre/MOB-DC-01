//
//  dashboardViewController.swift
//  hangman
//
//  Created by Andre Shonubi on 2/13/15.
//  Copyright (c) 2015 Andre Shonubi. All rights reserved.
//

import UIKit

class dashboardViewController: UIViewController, Guess{
    
    @IBOutlet weak var wordResultLabel: UILabel!
    @IBOutlet weak var remainingGuessLabel: UILabel!
    @IBAction func returnToFirstVCButton(sender: AnyObject) {
        let vc = self.storyboard?.instantiateViewControllerWithIdentifier("dashboard") as ViewController
        vc.delegate = self
        self.presentViewController(vc, animated: true, completion: nil)
    }
    
    
    
    func passGuess(enteredGuess: String) {
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        //create frame for hangman body
        var hangmanFrame = UIView(frame: CGRect(x: 0,
            y: 30,
            width: self.view.frame.width,
            height: 310))
        hangmanFrame.backgroundColor = UIColor.purpleColor()
        hangmanFrame.autoresizingMask = UIViewAutoresizing.FlexibleBottomMargin | UIViewAutoresizing.FlexibleRightMargin
        self.view.addSubview(hangmanFrame)

    }
    
}
